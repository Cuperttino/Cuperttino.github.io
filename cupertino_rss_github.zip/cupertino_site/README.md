# Cupertino — web de noticias Apple

Web estática que consulta feeds RSS públicos oficiales de Apple Newsroom y Apple Developer mediante GitHub Actions. La web no necesita una API key.

## Publicación gratuita en GitHub Pages

1. Crea una cuenta en https://github.com/ si no tienes una.
2. Crea un repositorio **público** llamado `cupertino`.
3. Sube todos los archivos y carpetas de este paquete manteniendo su estructura. `index.html`, `scripts/` y `.github/` deben quedar en la raíz del repositorio.
4. En el repositorio, abre **Settings → Pages** y en **Build and deployment → Source** elige **GitHub Actions**.
5. Abre **Actions**, selecciona `Update Apple RSS and publish Cupertino` y pulsa **Run workflow**.
6. Cuando el proceso termine en verde, vuelve a **Settings → Pages** y abre **Visit site**. La URL será parecida a `https://TU-USUARIO.github.io/cupertino/`.
7. El workflow vuelve a consultar las fuentes cada seis horas y publica la web con el nuevo `news.json`. También se ejecuta al subir cambios y se puede lanzar manualmente.

## Fuentes configuradas

- https://www.apple.com/es/newsroom/rss-feed.rss
- https://www.apple.com/newsroom/rss-feed.rss (respaldo)
- https://developer.apple.com/news/rss/news.rss

## Limitaciones importantes

- RSS permite actualizar titulares, extractos disponibles, fechas y enlaces; no crea resúmenes originales con IA ni inventa curiosidades.
- Si Apple cambia o interrumpe un feed, el paso puede fallar; revisa la pestaña Actions. El sitio publicado previamente seguirá disponible.
- GitHub Pages publica el repositorio en Internet. No subas claves, contraseñas ni datos privados.
- Los horarios de GitHub Actions son aproximados; no garantizan una hora exacta.

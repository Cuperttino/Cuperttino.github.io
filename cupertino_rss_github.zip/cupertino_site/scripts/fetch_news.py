import json, re, urllib.request, xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from html import unescape
from pathlib import Path

FEEDS = [
    ("Apple Newsroom", "https://www.apple.com/es/newsroom/rss-feed.rss"),
    ("Apple Newsroom", "https://www.apple.com/newsroom/rss-feed.rss"),
    ("Apple Developer", "https://developer.apple.com/news/rss/news.rss"),
]
HEADERS = {"User-Agent": "CupertinoNewsBot/1.0 (+https://github.com; official public RSS reader)"}
def clean(s):
    s = re.sub(r"<[^>]+>", " ", unescape(s or ""))
    return re.sub(r"\s+", " ", s).strip()
def local_name(tag): return tag.rsplit('}', 1)[-1].lower()
def child_text(el, names):
    for child in el.iter():
        if child is el: continue
        if local_name(child.tag) in names and child.text and child.text.strip(): return child.text.strip()
    return ""
def parse_date(raw):
    if not raw: return ""
    try:
        dt = parsedate_to_datetime(raw)
        if dt.tzinfo is None: dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc).strftime('%Y-%m-%d')
    except Exception:
        try: return raw[:10]
        except Exception: return ""
def fetch(url):
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=25) as res: data = res.read()
    root = ET.fromstring(data)
    items=[]
    for node in root.iter():
        if local_name(node.tag) not in ('item','entry'): continue
        title=child_text(node, {'title'})
        link=''
        for ch in node:
            if local_name(ch.tag)=='link':
                link=ch.attrib.get('href') or (ch.text or '').strip()
                if link: break
        desc=child_text(node, {'description','summary','encoded','content'})
        date=child_text(node, {'pubdate','published','updated','date'})
        if title and link and link.startswith('http'):
            items.append({'title':clean(title), 'summary':clean(desc)[:420], 'url':link, 'date':parse_date(date)})
    return items

def main():
    all_items=[]; feed_status=[]
    # Prefer the Spanish Newsroom feed; use the global feed only as a fallback.
    newsroom_items=[]
    for name,url in FEEDS[:2]:
        try:
            items=fetch(url); feed_status.append({'source':name,'url':url,'items':len(items)})
            if items:
                newsroom_items=items
                if '/es/' in url: break
        except Exception as e:
            feed_status.append({'source':name,'url':url,'error':str(e)[:180]})
    all_items.extend(newsroom_items)
    # Always include Apple Developer news as a second source.
    name,url=FEEDS[2]
    try:
        items=fetch(url); feed_status.append({'source':name,'url':url,'items':len(items)})
        all_items.extend(items)
    except Exception as e:
        feed_status.append({'source':name,'url':url,'error':str(e)[:180]})
    # Dedupe by canonical link and title; sort newest first where date exists.
    unique=[]; seen=set()
    for item in all_items:
        key=item['url'].split('?')[0].rstrip('/') or item['title'].lower()
        if key not in seen: seen.add(key); unique.append(item)
    unique.sort(key=lambda x:x.get('date',''), reverse=True)
    output={'generated_at':datetime.now(timezone.utc).isoformat(), 'items':unique[:36], 'sources':feed_status}
    Path('news.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f"Generated news.json with {len(output['items'])} articles")
    if not output['items']: raise SystemExit('No RSS items found; refusing to publish an empty news list')
if __name__=='__main__': main()
